import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Pattern;

public class Lab8 
{
	public static void main(String[] args) 
	{
		ArrayList<String> dataItems = new ArrayList<String>(100);
		Scanner keyboard = new Scanner(System.in);
		
		int counter = 0;
		int choice = 0;
		while(choice != 3)
		{
			displayMenu();
			if(keyboard.hasNext(Pattern.compile("[1-3]")))
			{
				choice = keyboard.nextInt();
				switch(choice)
				{
				case 1: // Add String to array dataItems
					if(!addTo(keyboard, dataItems, counter));
						break;
				case 2: // Search for a string in the array dataItems
					System.out.println(dataItems);
					break;
				case 3: // Quit
					break;
				default: // Should Never Get Here
					break;
				}
			}
			else
			{
				System.err.println("Invalid choice\n");
				choice = 0;
				keyboard.next();
			}
		}
		keyboard.close();
	}
	
	public static void displayMenu()
	{
		System.out.println("1: Add Value to Arraylist dataItems");
		System.out.println("2: Search for a string in the array dataItems");
		System.out.println("3: Exit");
		System.out.print("> ");
	}
	
	private static boolean addTo(Scanner keyboard, ArrayList<String> dataItems, int counter)
	{
		boolean valid = true;
		String x = null;
		
		while(valid)
		{
			System.out.print("Enter a string to add to the array list dataItems: ");
			x = keyboard.nextLine();
			if(x!=null)
			{
				valid = true;
				String toAdd = keyboard.next();
				dataItems.add(toAdd);
				break;
			}
			else
			{
				System.out.println("Invalid value");
				valid = false;
			}
		}
		
		int hashValue = hash(dataItems.get(counter));
		counter++;
		System.out.print(hashValue + "\n");
		System.out.print(counter);
		
		return valid;
	}
	
	private static int hash(String hash)
	{
		int total = 0;
		
		for (int i = 0; i < hash.length(); i++)
			total += (int)hash.charAt(i);
		
		return total % 100;
	}
}
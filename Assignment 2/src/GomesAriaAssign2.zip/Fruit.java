import java.util.Formatter;
import java.util.Scanner;

/**
 * Type of FoodItem called Fruit
 * @author Aria Gomes
 * @version 2.0
 * @since 11.0.5.10
 * @see FoodItem
 */
public class Fruit extends FoodItem 
{
	/**
	 * private member variable orchard Name
	 */
	private String orchardName;

	/**
	 * Default Constructor
	 */
	public Fruit() 
	{
		super();
		orchardName = "";
	}
	
	/**
	 * Outputs vegetable to external file
	 * @param outputFile Object used to write to the external file
	 */
	public void outputItem(Formatter outputFile)
	{
		outputFile.format("f" + "\n");
		super.outputItem(outputFile);
		outputFile.format("name of the orchard" + "\n");
	}
	
	/**
	 * Adds an item for the Fruit portion of type FoodItem
	 * @param scanner used to get user input to get preserve details of the foodItem
	 * @param fromFile tells the method if we are reading from a external file
	 */
	@Override
	public boolean addItem(Scanner scanner, boolean fromFile) 
	{
		
		if(!fromFile)
		{
			super.addItem(scanner, fromFile);
			System.out.print("Enter the name of the orchard supplier: ");
			orchardName = scanner.next();	
			return true;
		}
		else
		{
			super.addItem(scanner, fromFile);
			orchardName = scanner.nextLine();
			return false;
		}
		
	}

	/**
	 * returns vegetable portion of the toString method in proper format to previous method
	 */
	@Override
	public String toString() 
	{
		return super.toString()+" orchard supplier: "+orchardName;
	}
}
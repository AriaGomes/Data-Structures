import java.util.Formatter;
import java.util.Scanner;

/**
 * Type of FoodItem called Preserve
 * @author Aria Gomes
 * @see FoodItem
 * @since jdk11.0.5.10
 * @version 2.0
 */
public class Preserve extends FoodItem 
{
	/**
	 *  jarSize data member 
	 */
	private int jarSize;
	
	
	/**
	 * Default Constructor
	 */
	public Preserve() 
	{
		super();
		jarSize = 0;
	}

	
	/**
	 * Adds an item for the preserve portion of type FoodItem
	 * @param scanner used to get user input to get preserve details of the foodItem
	 * @param fromFile tells the method if we are reading from a external file
	 */
	@Override
	public boolean addItem(Scanner scanner, boolean fromFile) 
	{
		if (!fromFile)
		{
			super.addItem(scanner, false);
			System.out.println("Enter the size of the jar in millilitres: ");
			jarSize = scanner.nextInt();
		}
		else
		{
		boolean valid = false;
		if(super.addItem(scanner, false))
		{
			// Input quantity
			while(!valid)
			{
				System.out.print("Enter the size of the jar in millilitres: ");
				if(scanner.hasNextInt())
				{
					jarSize = scanner.nextInt();
					if(jarSize < 0)
					{
						valid = false;
						System.err.println("Invalid input");
						jarSize = 0;
					}
					else
						valid = true;				
				}
				else
				{
					System.err.println("Invalid input");
					scanner.next();
					valid = false;
				}
			}
		}
		return true;
		}
		return fromFile;
	}

	/**
	 * Outputs vegetable to external file
	 * @param outputFile Object used to write to the external file
	 */
	public void outputItem(Formatter outputFile)
	{
		outputFile.format("p" + "\n");
		super.outputItem(outputFile);
		outputFile.format("size of the jar" + "\n");
	}
	
	/**
	 * returns vegetable portion of the toString method in proper format to previous method
	 */
	@Override
	public String toString() 
	{
		return super.toString()+" size: "+jarSize+"mL";
	}
}
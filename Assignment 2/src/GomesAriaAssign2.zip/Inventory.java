import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Formatter;
import java.util.Scanner;
import java.util.regex.Pattern;

/**
 * Inventory of the FoodItem Class, contains logic for the FoodItem class and is one of the two main classes in this project 
 * @author Aria Gomes
 * @since jdk 11.0.5.10
 * @version 2.0
 */
public class Inventory
{
	/**
	 * Formatter Object used to write inventory data to the external file
	 */
	private Formatter outputFile;
	
	/**
	 * List of FoodItems that represents our inventory initialized at 20 elements
	 */
	protected static ArrayList <FoodItem> inventory = new ArrayList<>(20);

	/**
	 * Number of items currently stored in the inventory
	 */
	private int numItems;
	
	/**
	 * Reads from the Scanner object passed in and fills the data member fields of the class with valid data.
	 * @param scanner - Scanner to use for input
	 * @param fromFile 
	 * @return <code>true</code> if all data members were successfully populated, <code>false</code> otherwise
	 */
	public boolean addItem(Scanner scanner, boolean fromFile) 
	{
		
		boolean valid = true;
		boolean success = true;
		
		if(!fromFile)
		{
		    success = false;
		if(numItems >= 20)
		{
			System.err.println("Inventory full");
		}
		else
		{
			
		valid = true;
		
		while(valid)
		{
			System.out.print("Do you wish to add a fruit(f), vegetable(v) or a preserve(p)? ");
			if(scanner.hasNext(Pattern.compile("[fFvVpP]")))
			{
				String choice = scanner.next();
				switch(choice.toLowerCase())
				{
				case "f":
					inventory.add(new Fruit());
					do {
						inventory.get(numItems).inputCode(scanner);
						}while(alreadyExists(inventory.get(numItems)) == 1);
					inventory.get(numItems).addItem(scanner, false);
					numItems++;
					success = true;
					valid = false;
					break;
				case "v":
					inventory.add(new Vegetable());
					do {
						inventory.get(numItems).inputCode(scanner);
						}while(alreadyExists(inventory.get(numItems)) == 1);
					inventory.get(numItems).addItem(scanner, false);
					numItems++;
					success = true;
					valid = false;
					break;
				case "p":
					inventory.add(new Vegetable());
					do {
						inventory.get(numItems).inputCode(scanner);
						}while(alreadyExists(inventory.get(numItems)) == 1);
					inventory.get(numItems).addItem(scanner, false);
					numItems++;
					success = true;
					valid = false;
					break;
				default: // Should not get here.
					break;
				}
			}
			else
			{
				System.out.println("Invalid entry");
				scanner.next();
				valid = false;
			}
		}
		}
		}
		return success;
		}

	/**
	 * Search for a food item and see if it is already stored in the inventory
	 * @param item - FoodItem to look for
	 * @return - The index of item if it is found, -1 otherwise
	 */
	public int alreadyExists(FoodItem item) 
	{
		for(int i=0;i<numItems;i++)
		{
			if(inventory.get(i).isEqual(item))
				return i;
		}
		return -1;
	}

	/**
	 * Update the quantity stored in the food item
	 * @param scanner - Input device to use 
	 * @param buyOrSell - If we are to add to quantity (<code>true</code>) or remove (<code>false</code>)
	 * @return success status of method 
	 */
	public boolean updateQuantity(Scanner scanner, boolean buyOrSell) 
	{
		// If there are no items then we can't update, return
		if(numItems == 0)
			return false;

		FoodItem temp = new FoodItem();
		temp.inputCode(scanner);
		int index = alreadyExists(temp);
		if(index != -1)
		{
			String buySell = buyOrSell?"buy":"sell";
			System.out.print("Enter valid quantity to "+buySell+": ");
			if(scanner.hasNextInt())
			{
				int amount = scanner.nextInt();
				if(amount > 0)
				{
					return inventory.get(index).updateItem(buyOrSell? amount: amount*-1);
				}
				else
				{
					System.err.println("Invalid quantity...");
				}
			}
			else
			{
				System.err.println("Invalid quantity...");
			}
		}
		return false;
	}

	
	/**
	 * Writes current inventory ArrayList to specified external filename chosen by the user
	 * @param input is a Scanner Object used to name the external File
	 * @return method success status
	 */
	public boolean saveToFile(Scanner input)
	{
		boolean saved = true;
		
		String outputFileName;
		try 
		{
			System.out.println("Name of the file to save to: ");
			outputFileName = input.next();
			outputFile = new Formatter(outputFileName);
			
			for(int i = 0; i < numItems; i++)
			{
				inventory.get(i).outputItem(outputFile);
			}
			outputFile.close();
		}
		catch(FileNotFoundException e)
		{
			saved = false;
			//System.err.println("File not found.");
		}
		return saved;
	}
	
	/**
	 * Sorts the inventory ArrayList of type FoodItems
	 * @author Aria Gomes
	 */
	public void sortArrayList() 
	{
        FoodItem tempItem;
        int sortIndex;
        for (int i = 1; i < numItems; i++) {
            tempItem = inventory.get(i);
            sortIndex = i - 1;
            while (sortIndex >= 0 && inventory.get(sortIndex).getItemCode() > tempItem.getItemCode()) 
            {
                inventory.set(sortIndex+1, inventory.get(sortIndex));
                sortIndex = sortIndex - 1;
            }
            inventory.set(sortIndex+1, tempItem);
        }
    }
	  
	
	/**
	 * TODO (This function does not work properly)
	 * Reads values from an external file and adds them into the existing inventory ArrayList of type FoodItem
	 * @param input is a Scanner object used to specify which file to read from
	 * @return the exit status of the method
	 * @throws FileNotFoundException
	 */
	public boolean readFromFile(Scanner input) throws FileNotFoundException
	{
		boolean read = true;
		String inFileName;
		FoodItem temp = new FoodItem();
		
		System.out.println("Please enter the file name: ");
		inFileName = input.next();

		try 
		{
			Scanner inputFile = new Scanner(new File(inFileName));
			while(inputFile.hasNext())
			{
				
				String itemType = inputFile.next();
				itemType.toLowerCase();
				if (itemType.matches("f"))
				{
					temp = new Fruit();
					temp.addItem(inputFile, true);
					if(compareTo(temp) == 0)
					{
						throw new Exception();
					}
				}
				inventory.add(temp);
				numItems++;
				sortArrayList();
				if (itemType.matches("v"))
				{
					temp = new Vegetable();
					temp.addItem(inputFile, true);
					if(compareTo(temp) == 0)
					{
						throw new Exception();
					}
				inventory.add(temp);
				numItems++;
				sortArrayList();
				
				}
				if (itemType.matches("p"))
				{
					temp = new Preserve();
					temp.addItem(inputFile, true);
					if (compareTo(temp) == 0)
					{
						throw new Exception();
					}
					inventory.add(temp);
					numItems++;
					sortArrayList();
				}
				else
				{
					System.out.println("Invalid entry");
					input.next();
					read = false;
				}
			}
			if(temp.inputCode(input))
			{
				if(alreadyExists(temp)<0)
				{
					if(temp.addItem(input, true))
					{
						inventory.add(temp);
						numItems++;
						return true;
					}
					else
						return false;
				}
				else
				{
					System.out.println("Item code already exists");
					return false;
				}
			}
			inputFile.close();	
			return true;
		}
		catch(Exception e)
		{
			System.err.println("Error adding values from file(Not Complete)");
		}
		return read;
	}
	
	/**
	 * Compares two instances of type FoodItem's itemcodes(Similar to comparator)
	 * @param arg1 instance of type FoodItem
	 * @return result
	 */
	public int compareTo(FoodItem arg1) 
	{

		int found = 1;
		
		for(int i = 0; i < numItems; i++)
		{
			if(inventory.get(i).getItemCode() == arg1.getItemCode())
			{
				found = 0;
			}
		}
		if (found == 1)
			return 1;
		else
			return 0;
	}

	/**
	 * Searches the ArrayList of type FoodItem for a specified value by splitting the Arraylist in half and searching through each half.
	 * The Time complexity for this method is O(log n) 
	 * @param arr The array list of type FoodItem which will be binarySearched
	 * @param x the value that will be searched for in the algorithm
	 * @return The index of the value we were looking for, if it does not exist the method will return -1
	 */
	public static int binarySearch(ArrayList<FoodItem> arr, int x) 
    { 
        int l = 0, r = arr.size() - 1; 
        while (l <= r) 
        { 
            int m = l + (r - l) / 2; 
  
            // Check if x is present at mid 
            if (arr.get(m).getItemCode() == x) 
                return m; 
  
            // If x greater, ignore left half 
            if (arr.get(m).getItemCode() < x) 
                l = m + 1; 
  
            // If x is smaller, ignore right half 
            else
                r = m - 1; 
        } 
  
        // if we reach here, then element was 
        // not present 
        return -1; 
    } 
	
	/*
	 * toString method returns the entire inventory ArrayList of type FoodItem in proper format
	 * @return String in proper format
	 */
	@Override
	public String toString() 
	{
		String returnString = "Inventory:\n";
		for(int i=0;i<numItems;i++)
			returnString += inventory.get(i).toString() + "\n";
		return returnString;
	}
}
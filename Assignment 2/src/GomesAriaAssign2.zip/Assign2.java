import java.util.Scanner;
import java.util.regex.Pattern;

/**
 * Driver class for Inventory Class
 * @author Aria Gomes
 * @version 2.0
 * @since jdk11.0.5.10
 * @see FoodItem
 * @see Inventory
 * @see Fruit
 * @see Vegetable
 * @see Preserve
 */
public class Assign2 
{
	
	/**
	 * private reference to type Inventory
	 */
	private static Inventory inventory;
	
	/**
	 * Main Menu
	 * @param args - Parameters passed into the application
	 */
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		scanner.useDelimiter(Pattern.compile("[\\r\\n]+"));
		inventory = new Inventory();
		int choice = 0;
		while (choice != 8) 
		{
			try
			{
				displayMenu();
				if (scanner.hasNext(Pattern.compile("[1-8]"))) 
				{
					choice = scanner.nextInt();
					switch(choice)
					{
					case 1: // Add Item
						if(!inventory.addItem(scanner, false))
							System.err.println("Error...could not add item");
						break;
					case 2: // Display Current Inventory
						System.out.println(inventory);
						break;
					case 3: // Buy Item(s)
						if(!inventory.updateQuantity(scanner, true))
							System.err.println("Error...could not buy item");
						break;
					case 4: // Sell Item(s)
						if(!inventory.updateQuantity(scanner, false))
							System.err.println("Error...could not sell item");
						break;
					case 5: // Search for Item
						if(!binarySearch(scanner))
							System.err.println("Error...could not search for item");
						break;
					case 6: // Save Inventory to File
						if(!(inventory.saveToFile(scanner)))
								System.err.println("Error...could not search for item");
						break;
					case 7: // Read Inventory from File
						if(!(inventory.readFromFile(scanner)))
							System.err.println("Error...Could not read from file");
						break;
					case 8: // To Exit
						System.err.println("Exiting...");
						break;
					default: // Should never get here
						System.err.println("Something went wrong");
						break;
					}
				} else 
				{
					System.err.println("Incorrect value entered");
					scanner.next();
				}
			}
			catch(Exception e)
			{
				System.err.println("\nError Occurred: " +e.getMessage());
			}
		}
		scanner.close();
	}

	/**
	 * Helper method to display menu
	 */
	public static void displayMenu() 
	{
		System.out.println("Please select one of the following:");
		System.out.println("1: Add Item to Inventory");
		System.out.println("2: Display Current Inventory");
		System.out.println("3: Buy Item(s)");
		System.out.println("4: Sell Item(s)");
		System.out.println("5: Search For Items");
		System.out.println("6: Save to File");
		System.out.println("7: Read from File");
		System.out.println("8: To Exit");
		System.out.print("> ");
	}
	
	/**
	 * Prompts user for an itemCode to iterate through the list for and calls the binarySearch method in the FoodItem class
	 * @param keyboard Scanner object used to get the value to be searched for in the ArrayList
	 * @return exit status of the operation
	 */
	public static boolean binarySearch(Scanner keyboard)
	{
		boolean exit = true;
		int valueToSearch = 0, result = 0;
		
		while (exit)
		{
			
			System.out.println("Enter the code for the item: ");
			valueToSearch = keyboard.nextInt();
			
			if(!(valueToSearch == (int)valueToSearch))
			{
				exit = false;
				if (result == -1)
					System.err.println("Element not present"); 
			}
			else
			{
				result = Inventory.binarySearch(Inventory.inventory, valueToSearch);
				
				System.out.println(Inventory.inventory.get(result));
				if(result == -1)
					continue;
				else
					break;
			}
		}
		return exit;
	}
}
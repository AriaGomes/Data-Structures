import java.util.Formatter;
import java.util.Scanner;
/**
 * FoodItem is the main class that has all the member variables for type FoodItem and most of the logic to control the functions
 * @author Aria Gomes
 * @since jdk11.0.5.10
 * @version 2.0
 * @see Inventory
 */
public class FoodItem implements Comparable<FoodItem>
{	
	
	/**
	 * private member variable item Code
	 */
	private int itemCode;

	/**
	 * private member variable item Name
	 */
	private String itemName;

	/**
	 * private member variable item Price
	 */
	private float itemPrice;
	
	/**
	 * private member variable item Cost
	 */
	private float itemCost;
	
	
	/**
	 * private member variable itemQuantityInStock
	 */
	private int itemQuantityInStock;

	/**
	 * Default Constructor
	 */
	public FoodItem() 
	{
		setItemCode(0);
		itemName = "";
		itemPrice = 0.0f;
		itemCost = 0.0f;
		itemQuantityInStock = 0;
	}

	/**
	 * Reads from the Scanner object passed in and fills the data member fields of the class with valid data.
	 * @param scanner - Scanner to use for input
	 * @param fromFile 	 
	 * @return <code>true</code> if all data members were successfully populated, <code>false</code> otherwise
	 */
	public boolean addItem(Scanner scanner, boolean fromFile) 
	{
		boolean valid = false;

		if(!fromFile)
		{
		
		System.out.print("Enter the name for the item: ");
		itemName = scanner.next();
		// Input quantity
		while(!valid)
		{
			System.out.print("Enter the quantity for the item: ");
			if(scanner.hasNextInt())
			{
				itemQuantityInStock = scanner.nextInt();
				if(itemQuantityInStock < 0)
				{
					valid = false;
					System.err.println("Invalid input");
					itemQuantityInStock = 0;
				}
				else
					valid = true;				
			}
			else
			{
				System.err.println("Invalid input");
				scanner.next();
				valid = false;
			}
		}
	}
		else 
		{
			itemCode = scanner.nextInt();
			scanner.nextLine();
			itemName = scanner.nextLine();
			itemQuantityInStock = scanner.nextInt();
			scanner.nextLine();
			itemCost = scanner.nextFloat();
			itemPrice = scanner.nextFloat();
			scanner.nextLine();
			return true;
		}
	

		// Input the cost
		valid = false;
		while(!valid)
		{
			System.out.print("Enter the cost of the item: ");
			if(scanner.hasNextFloat())
			{
				itemCost = scanner.nextFloat();
				if(itemCost < 0)
				{
					valid = false;
					System.err.println("Invalid input");
					itemCost = 0;
				}
				else
					valid = true;
			}
			else
			{
				System.err.println("Invalid input");
				scanner.next();
				valid = false;
			}
		}

		// Input the price
		valid = false;
		while(!valid)
		{
			System.out.print("Enter the sales price of the item: ");
			if(scanner.hasNextFloat())
			{
				itemPrice = scanner.nextFloat();
				if(itemPrice < 0)
				{
					valid = false;
					System.err.println("Invalid input");
					itemPrice = 0;
				}
				else
					valid = true;
			}
			else
			{
				System.err.println("Invalid input");
				scanner.next();
				valid = false;
			}
		}
		return true;
	}

	/**
	 * Reads a valid itemCode from the Scanner object and returns true/false if successful
	 * @param scanner - Scanner to use for input
	 * @return <code>true</code> if code was populated, <code>false</code> otherwise
	 */
	public boolean inputCode(Scanner scanner) 
	{
		boolean validInput = false;
		while(!validInput)
		{
			//System.out.print("Enter valid item code: ");
			System.out.print("Enter the code for the item: ");
			if(scanner.hasNextInt())
			{
				setItemCode(scanner.nextInt());
				validInput = true;
			}
			else
			{
				System.err.println("Invalid code");
				// Clear the invalid input
				scanner.next();
			}
		}
		return validInput;
	}

	/**
	 * Compares this object's item code with the one passed in
	 * @param item - object to compare with
	 * @return <code>true</code> if the itemCode of the object being acted on and the item object parameter are the same value, <code>false</code> otherwise
	 */
	public boolean isEqual(FoodItem item) 
	{
		return getItemCode() == item.getItemCode();
	}

	/**
	 * Updates the quantity field by amount (note amount could be positive or negative)
	 * @param amount - what to update by, either can be positive or negative
	 * @return Method returns <code>true</code> if successful, otherwise returns <code>false</code>
	 */
	public boolean updateItem(int amount) 
	{
		// If you are removing stock, then check that we have enough stock
		if(itemQuantityInStock < amount * -1)	
			return false;
		
		itemQuantityInStock += amount;
		return true;
	}
	
	/**
	 * Gets the itemcode for an instance of FoodItem
	 * @return itemCode of instance
	 */
	public int getItemCode()
	{
		return itemCode;
	}	
	    		
			/**
			* returns the Array list in proper format
			* @return String formated in proper format
			*/
			@Override
			public String toString() 
			{
				return "Item: "+getItemCode()+" "+itemName+" "+itemQuantityInStock+" price: $"+String.format("%.2f", itemPrice)+" cost: $"+String.format("%.2f", itemCost);
			}

			/**
			 * Sets the itemCode to a specified value
			 * @param itemCode specified value 
			 */
			public void setItemCode(int itemCode) 
			{
				this.itemCode = itemCode;
			}
			
			
			/**
			 * Compares two instances of FoodItem and returns a value 
			 * 
			 * @author Aria Gomes
			 * @param f1 
			 * @param f2 
			 * @return result
			 */	
			 public int compareTo(FoodItem f1, FoodItem f2)
		        {
		            //this > f2 = +
		            //this < f2 = -
		            //this == f2 = 0
		            
		            if(this.itemCode > f2.getItemCode())
		                return 1;
		            else if(this.getItemCode() == f2.getItemCode())
		                return 0;
		            else    
		                return -1;
		        }

			 /**
			  * Comparator method, can be used to sort Arrays
			  * I didn't understand how to use this with the limitations of not allowed the use of the Collections class as stated in your documentation
			  */
			@Override
			public int compareTo(FoodItem o) 
			{
				return compareTo(o, new FoodItem());
			}

			/**
			 * Outputs the given string to the external file in the proper format
			 * @param outputFile
			 */
			public void outputItem(Formatter outputFile) 
			{
				outputFile.format(itemCode + "\n" + itemName + "\n" + itemQuantityInStock + "\n" + itemCost + "\n" + itemPrice + "\n");
			}
		
	}

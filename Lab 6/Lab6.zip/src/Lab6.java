import java.util.LinkedList;
import java.util.Scanner;

public class Lab6 
{

	static LinkedList<String> stack = new LinkedList<String>();
	static Scanner scanner = new Scanner(System.in);
	
	public static void main(String args[])
	{
		String userIn = "";
		
		while(!userIn.equals("exit"))
		{
			
			
			System.out.print("Enter an expression (or exit to terminate): ");
			userIn = scanner.nextLine();
			userIn = userIn.toLowerCase();
			
		if(!userIn.equals("exit"))
		{
		 String checkBalancedExpr=checkBalancedParentesis(userIn);
		 System.out.println(checkBalancedExpr);
		}
		else
			break;
		}
	}

	
	
	public static String checkBalancedParentesis(String expr)
	{
		if (expr.isEmpty())
			return "The expression is NOT balanced";


		for (int i = 0; i < expr.length(); i++)
		{
			char current = expr.charAt(i);
			if (current == '{' || current == '(' || current == '[')
				stack.push(String.valueOf(current)); 
			
			if (current == '}' || current == ')' || current == ']')
			{
				char last = stack.peekFirst().charAt(0);   
				if (current == '}' && last == '{')
				{
					stack.pop();
				}
				if (current == ')' && last == '(')
				{
					stack.pop();
				}
				if (current == ']' && last == '[')
				{
					stack.pop();
				}
				
			}
		}
		return stack.isEmpty()?"The expression is balanced":"The expression is NOT balanced";
	}
		 
}
